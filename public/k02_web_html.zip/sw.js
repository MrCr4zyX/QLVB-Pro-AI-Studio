/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  importScripts("./sw-notification.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notification.js",
    "revision": "7d3e76eaac508251c30ead91a2f7b58d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9e9ca9b9acb2043a43e1b3e7c6432c47"
  }, {
    "url": "manifest.webmanifest",
    "revision": "5f1d898dd764339d1e0fc46a60ea6743"
  }, {
    "url": "index.html",
    "revision": "b818f9f9cd2a0c6e4a12bdc149560f2c"
  }, {
    "url": "icon.svg",
    "revision": "082b708b2a5e41573434eac1e143d208"
  }, {
    "url": "favicon.ico",
    "revision": "29c56f2b3ec23c907180341a08413471"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5e54dcd60a74103a9ac173334a0d77b0"
  }, {
    "url": "app-logo.png",
    "revision": "1516d552b6ce2cc82703fbedcd095ac3"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/web-BHRw0fQ4.js",
    "revision": null
  }, {
    "url": "assets/index-FwLi7Q56.css",
    "revision": null
  }, {
    "url": "assets/index-DV1HrQlD.js",
    "revision": null
  }, {
    "url": "assets/app-logo-B_tVPXg8.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ad3404a0.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_5c42478d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_0428f0a9.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5e54dcd60a74103a9ac173334a0d77b0"
  }, {
    "url": "favicon.ico",
    "revision": "29c56f2b3ec23c907180341a08413471"
  }, {
    "url": "icon.svg",
    "revision": "082b708b2a5e41573434eac1e143d208"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9e9ca9b9acb2043a43e1b3e7c6432c47"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "sw-notification.js",
    "revision": "7d3e76eaac508251c30ead91a2f7b58d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "5f1d898dd764339d1e0fc46a60ea6743"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
