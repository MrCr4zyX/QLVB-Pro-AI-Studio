/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  importScripts("./sw-notification.js");
  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "sw-notification.js",
    "revision": "7d3e76eaac508251c30ead91a2f7b58d"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c741a8c616d4adc4d8407003a7c4f591"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9e9ca9b9acb2043a43e1b3e7c6432c47"
  }, {
    "url": "manifest.webmanifest",
    "revision": "6ce27d867d2045841cad38d515ccff27"
  }, {
    "url": "index.html",
    "revision": "b7cf57678d9b9bde4cad00bb43686c81"
  }, {
    "url": "icon.svg",
    "revision": "082b708b2a5e41573434eac1e143d208"
  }, {
    "url": "favicon.ico",
    "revision": "29c56f2b3ec23c907180341a08413471"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5e54dcd60a74103a9ac173334a0d77b0"
  }, {
    "url": "app-logo.png",
    "revision": "1516d552b6ce2cc82703fbedcd095ac3"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/web-B17GC7rx.js",
    "revision": null
  }, {
    "url": "assets/index-D-ADMvWO.css",
    "revision": null
  }, {
    "url": "assets/index-CyPWOSHM.js",
    "revision": null
  }, {
    "url": "assets/app-logo-B_tVPXg8.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_fae15962.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_f5ac61e7.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_eae86f02.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_e9043462.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_e3c4d19d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_e33f3816.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_e2b8fa19.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_dc111b80.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_d07bf267.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_c4c73369.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_be6b28f8.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_b1858d93.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ad3404a0.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_ad0079ce.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_acfa1f5e.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_8ec6ffe8.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_8e4df095.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_87bcee23.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_8389dd60.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_76452786.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_64a6a89a.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_5c42478d.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_4c254346.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_49bee61f.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_482fb0bc.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_45a81ee1.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_44fea16a.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_32ac6d0a.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_195b3422.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_0428f0a9.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_2026-10-29-17-12-15-064_com.k02.qlvbpro_a6a3d147.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "5e54dcd60a74103a9ac173334a0d77b0"
  }, {
    "url": "favicon.ico",
    "revision": "29c56f2b3ec23c907180341a08413471"
  }, {
    "url": "icon.svg",
    "revision": "082b708b2a5e41573434eac1e143d208"
  }, {
    "url": "pwa-192x192.png",
    "revision": "9e9ca9b9acb2043a43e1b3e7c6432c47"
  }, {
    "url": "pwa-512x512.png",
    "revision": "2cd87b31041f7b3897fb134165193825"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "c741a8c616d4adc4d8407003a7c4f591"
  }, {
    "url": "sw-notification.js",
    "revision": "7d3e76eaac508251c30ead91a2f7b58d"
  }, {
    "url": "manifest.webmanifest",
    "revision": "6ce27d867d2045841cad38d515ccff27"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html"), {
    denylist: [/^\/__\/auth\//, /^\/api\//]
  }));

}));
